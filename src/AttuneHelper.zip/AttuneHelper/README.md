# AttuneHelper

A simple addon to add some QOL for attunements

Features:
- /ath

## Dependencies

- [SynastriaCoreLib](https://github.com/imevul/SynastriaCoreLib/releases) (Optional)
